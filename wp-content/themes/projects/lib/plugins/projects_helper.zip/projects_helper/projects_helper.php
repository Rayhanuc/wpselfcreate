<?php

/**
 * Plugin Name: Projects-Helper
 * Plugin URI: https://github.com/Rayhanuc/projects
 * Description: Projects Helper plugin for Project help
 * Author: Md. Rayhan Uddin Chowdhury
 * Version: 1.0
 * Author URI: https://rayhanuddinchy.com/
 * Text Domain: projects_helper
 * Domain Path: /languages
 * License: GPL-2.0+
 * Requires at least: 5.9 
 * Requires PHP: 5.6
 * 
 */



function projects_helper_register_my_cpts_project() {

/**
 * Post Type: Projects.
 */

$labels = [
  "name" => esc_html__( "Projects", "projects" ),
  "singular_name" => esc_html__( "Project", "projects" ),
  "menu_name" => esc_html__( "Projects", "projects" ),
  "all_items" => esc_html__( "All Projects", "projects" ),
  "add_new" => esc_html__( "Add project", "projects" ),
  "add_new_item" => esc_html__( "Add New Project", "projects" ),
  "edit_item" => esc_html__( "Edit Project", "projects" ),
  "new_item" => esc_html__( "New Project", "projects" ),
  "view_item" => esc_html__( "View Project", "projects" ),
  "view_items" => esc_html__( "View Projects", "projects" ),
  "search_items" => esc_html__( "Search Projects", "projects" ),
  "featured_image" => esc_html__( "Project Image", "projects" ),
  "set_featured_image" => esc_html__( "Set Project Image", "projects" ),
  "remove_featured_image" => esc_html__( "Remove Project Image", "projects" ),
  "use_featured_image" => esc_html__( "Use Project Image", "projects" ),
  "archives" => esc_html__( "Projects Archives", "projects" ),
  "insert_into_item" => esc_html__( "Insert Into Project", "projects" ),
  "uploaded_to_this_item" => esc_html__( "Uploaded to this project", "projects" ),
  "filter_items_list" => esc_html__( "Filter Projects List", "projects" ),
  "items_list_navigation" => esc_html__( "Projects List Navigation", "projects" ),
  "items_list" => esc_html__( "Projects List", "projects" ),
  "name_admin_bar" => esc_html__( "New Project", "projects" ),
  "item_published" => esc_html__( "Project Published", "projects" ),
  "item_updated" => esc_html__( "Project Updated", "projects" ),
];

$args = [
  "label" => esc_html__( "Projects", "projects" ),
  "labels" => $labels,
  "description" => "",
  "public" => true,
  "publicly_queryable" => true,
  "show_ui" => true,
  "show_in_rest" => true,
  "rest_base" => "",
  "rest_controller_class" => "WP_REST_Posts_Controller",
  "rest_namespace" => "wp/v2",
  "has_archive" => "projects",
  "show_in_menu" => true,
  "show_in_nav_menus" => true,
  "delete_with_user" => false,
  "exclude_from_search" => false,
  "capability_type" => "post",
  "map_meta_cap" => true,
  "hierarchical" => false,
  "can_export" => false,
  "rewrite" => [ "slug" => "project", "with_front" => false ],
  "query_var" => true,
  "menu_icon" => "dashicons-format-aside",
  "supports" => [ "title", "editor", "thumbnail", "excerpt", "custom-fields" ],
  "taxonomies" => [ "category", "post_tag" ],
  "show_in_graphql" => false,
];

register_post_type( "project", $args );
}

add_action( 'init', 'projects_helper_register_my_cpts_project' );



// function add_projects_meta_boxes() {
//   add_meta_box(
//       'project_url',
//       'External URL',
//       'render_project_url_meta_box',
//       'projects',
//       'normal',
//       'default'
//   );

//   add_meta_box(
//       'project_description',
//       'Description',
//       'render_project_description_meta_box',
//       'projects',
//       'normal',
//       'default'
//   );

//   add_meta_box(
//       'project_preview_images',
//       'Preview Images',
//       'render_project_preview_images_meta_box',
//       'projects',
//       'normal',
//       'default'
//   );
// }
// add_action( 'add_meta_boxes', 'add_projects_meta_boxes' );

